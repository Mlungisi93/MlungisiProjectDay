import java.io.*;
import java.sql.*;
import java.util.Scanner;

import org.junit.After;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;

import org.junit.Before;
import org.junit.Test;

public class ProjectDayTest {

    private static Scanner sc;
    private static String fileName;
    private static Connection conn;
    private static Statement stmt;
    private static PreparedStatement pstmt;
    private static int count = 0;

    public static void main(String[] args) throws FileNotFoundException, SQLException{


        String[] data;
        String line;
        String databaseName;
        String tableName;
        String primaryKeyName;
        int primaryKeyValue;
        String otherColumnName;
        String otherColumnValue;
        File file;
        final String USER = "";
        final String PASS = "";

        //if continue the program is going to start here
        System.out.println("Welcome To My Program!");
        do {

            sc = new Scanner(System.in);

            input(sc); // asks the user to enter name of the file or type quit to exit the program

             if(fileName.equalsIgnoreCase("quit")) //exit the loop if user decides to qui
             {
                 System.out.println("Program Ended. Good Bye");
                 break;
             }
            file = new File(fileName + ".txt");

            //check if file exist
            if (file.exists() == true) {
                //check if file is not empty
                if (file.length() > 0) // file not empty
                {

                    try {



                        Scanner inputFileReader = new Scanner(new FileReader(file));
                        int countDelimeters = 0; // will count the ,delimeters
                        // Read the file and skip the first line
                        while (inputFileReader.hasNextLine()) // Read next line
                        {

                            line = inputFileReader.nextLine();

                            countDelimeters = 0; // restart count for each line
                            for (int i = 0; i < line.length(); i++) {

                                if(line.charAt(i) == ',')
                                {
                                    countDelimeters++;
                                }
                            }

                            if(countDelimeters != 5)
                            {
                                System.out.println("Line:"+line+" :is in a wrong format: Line should have 6 Values separated by comma");
                                System.out.println("");
                                count++;
                                continue;
                            }else
                            {
                                data = line.split(",");

                                try {
                                    databaseName = data[0];

                                    // check if databaseName exits
                                    File fileDatabase = new File(databaseName + ".db");
                                    if (count > 0) {
                                         //print out each line
                                        System.out.println("On Line: "  + count);

                                        if (fileDatabase.exists()) //here's how to check if the database exist
                                        {
                                            tableName = data[1]; //initialize table name
                                            //connect to sqlite database
                                            conn = DriverManager.getConnection("jdbc:sqlite:" + fileDatabase, USER, PASS);

                                            //check if table exists
                                            pstmt = conn.prepareStatement("SELECT count(*) as count FROM " +
                                                    "sqlite_master WHERE type='table' AND name =?");
                                            pstmt.setString(1, tableName);
                                            ResultSet rsNumberOfTables = pstmt.executeQuery();
                                            int numberOfTables = -1;

                                            while (rsNumberOfTables.next()) {
                                                numberOfTables = Integer.parseInt(rsNumberOfTables.getString("count"));
                                            }

                                            if (numberOfTables > 0) // table is found
                                            {
                                                //check if the primary key name
                                                primaryKeyName = data[2];

                                                // This method will check if column exists and is the primary key in your table
                                                pstmt = conn.prepareStatement("SELECT COUNT(*) AS CNTREC FROM pragma_table_info('" + tableName + "')" +
                                                        " WHERE name='" + primaryKeyName + "' AND pk=1");
                                                //pstmt.setString(1, "ArtistId");
                                                ResultSet rsNumberOfRec = pstmt.executeQuery();
                                                int numberOfColumbs = -1;

                                                while (rsNumberOfRec.next()) {
                                                    numberOfColumbs = Integer.parseInt(rsNumberOfRec.getString("CNTREC"));
                                                }

                                                if (numberOfColumbs > 0) // key columb found and its a primary key
                                                {
                                                    // check primary key value
                                                    try {
                                                        primaryKeyValue = Integer.parseInt(data[3]);
                                                        pstmt = conn.prepareStatement("SELECT COUNT(*) AS CNTREC FROM " + tableName +
                                                                " WHERE " + primaryKeyName + "='" + primaryKeyValue + "'");

                                                        ResultSet rsNumberOfRecPK = pstmt.executeQuery();
                                                        int numberOfRows = -1;

                                                        while (rsNumberOfRecPK.next()) {
                                                            numberOfRows = Integer.parseInt(rsNumberOfRecPK.getString("CNTREC"));
                                                        }

                                                        if (numberOfColumbs > 0) // row found using its a primary columb and value
                                                        {
                                                            otherColumnName = data[4];
                                                            pstmt = conn.prepareStatement("SELECT COUNT(*) AS CNTREC FROM pragma_table_info('" + tableName + "')" +
                                                                    " WHERE name='" + otherColumnName + "'");
                                                            //pstmt.setString(1, otherColumnName);
                                                            ResultSet rsNumberOfOtherColumb = pstmt.executeQuery();
                                                            int numberOfOtherColumbs = -1;

                                                            while (rsNumberOfOtherColumb.next()) {
                                                                numberOfOtherColumbs = Integer.parseInt(rsNumberOfOtherColumb.getString("CNTREC"));
                                                            }

                                                            if (numberOfOtherColumbs > 0) // key columb found and its a primary key
                                                            {
                                                                otherColumnValue = data[5];
                                                                pstmt = conn.prepareStatement("SELECT COUNT(*) AS CNTREC FROM " + tableName +
                                                                        " WHERE " + primaryKeyName + "='" + primaryKeyValue + "' AND " + otherColumnName + "='" +
                                                                        otherColumnValue + "'");
                                                                //pstmt.setInt(1, primaryKeyValue);
                                                                //pstmt.setString(2, otherColumnValue);
                                                                ResultSet rsNumberOfRecOther = pstmt.executeQuery();
                                                                int numberOfRowsOther = -1;

                                                                while (rsNumberOfRecOther.next()) {
                                                                    numberOfRowsOther = Integer.parseInt(rsNumberOfRecOther.getString("CNTREC"));
                                                                }

                                                                if (numberOfRowsOther > 0) // row found using its a primary columb and value
                                                                {
                                                                    //System.out.println("");
                                                                    System.out.println("OK");
                                                                    System.out.println("");
                                                                } else {
                                                                    try {
                                                                        //System.out.println("");
                                                                        assertThat(otherColumnName+"Columb has No Record Found: for: " + otherColumnValue+" value In "+tableName+" Table", numberOfRowsOther, greaterThan(0));
                                                                    } catch (AssertionError e) {
                                                                        System.out.println(e.getMessage());
                                                                        System.out.println("");
                                                                        count++;
                                                                        continue; // read next line

                                                                    }
                                                                }


                                                            } else {
                                                                try {
                                                                    //System.out.println("");
                                                                    assertThat("Invalid Columb: " + otherColumnName+" In "+tableName+" Table", numberOfOtherColumbs, greaterThan(0));

                                                                } catch (AssertionError e) {
                                                                    System.out.println(e.getMessage());
                                                                    System.out.println("");
                                                                    count++;
                                                                    continue; // read next line

                                                                }

                                                            }


                                                        } else {
                                                            try {
                                                                //System.out.println("");
                                                                assertThat("Invalid primary key value: " + primaryKeyValue+" In "+tableName+" Table", numberOfColumbs, greaterThan(0));

                                                            } catch (AssertionError e) {
                                                                System.out.println(e.getMessage());
                                                                System.out.println("");
                                                                count++;
                                                                continue; // read next line
                                                            }

                                                        }
                                                    }catch (NumberFormatException e)
                                                    {

                                                        System.out.println("Invalid integer: "+e.getMessage());
                                                        System.out.println("");
                                                        count++;
                                                        continue;

                                                    }



                                                } else {
                                                    try {
                                                        //System.out.println("");
                                                        assertThat("Invalid primary key name: " + primaryKeyName + " Columb is not a primary key for " + tableName + " Table", numberOfColumbs, greaterThan(0));
                                                    } catch (AssertionError e) {
                                                        System.out.println(e.getMessage());
                                                        System.out.println("");
                                                        count++;
                                                        continue; // read next line
                                                    }

                                                }


                                            } else // table does not exist
                                            {
                                                try {
                                                    //System.out.println("");
                                                    assertThat("Invalid table name: " + tableName + " Table does not exist In "+databaseName+" database", numberOfTables, greaterThan(0));
                                                } catch (AssertionError e) {
                                                    System.out.println(e.getMessage());
                                                    System.out.println("");
                                                    count++;
                                                    continue; // read next line
                                                }

                                            }


                                        } else {

                                            //.out.println("Invalid Database Name: \"+\"Database does not exist:\"+databaseName");
                                            try {
                                                //System.out.println("");
                                                assertThat("Invalid Database Name: " +databaseName+ " Database does not exist", fileDatabase.exists(), equalTo(true));

                                            } catch (AssertionError e) {
                                                System.out.println(e.getMessage());
                                                System.out.println("");
                                                count++;
                                                continue;// it should teake the user to reenter name
                                            }

                                        }

                                    }
                                    count++;
                                }catch (ArrayIndexOutOfBoundsException e)
                                {
                                    //System.out.println("");
                                    System.out.println("On Line"+count);
                                    if(e.getMessage().equals("0"))
                                    {
                                        System.out.println("Empty dababase name before: , at index: "+e.getMessage());
                                    }else if(e.getMessage().equals("1"))
                                    {
                                        System.out.println("Empty table name before: , at index "+e.getMessage());

                                    }else if(e.getMessage().equals("2"))
                                    {
                                        System.out.println("Empty Key Column name before: , at index "+e.getMessage());

                                    }else if(e.getMessage().equals("3"))
                                    {
                                        System.out.println("Empty Key Value before: , at index "+e.getMessage());

                                    }
                                    else if(e.getMessage().equals("4"))
                                    {
                                        System.out.println("Empty Column name before: , at index "+e.getMessage());

                                    }
                                    else if(e.getMessage().equals("5"))
                                    {
                                        System.out.println("Empty Column Value before: , at index "+e.getMessage());

                                    }

                                    System.out.println("");
                                    count++;
                                    continue;
                                }
                            }



                        } //end of while loop
                        inputFileReader.close();
                    } catch (IOException ex) {

                        System.out.println("There was a problem reading "
                                + "from the da ex.getMessagta storage device.\n "
                                + ex.getMessage());
                        System.out.println("");
                        count++;
                        continue;
                    }


                } else // file is empty
                {
                    try {
                        //System.out.println("");
                        assertThat(fileName+" File Is Empty.", Math.toIntExact(file.length()), greaterThan(0));
                    }catch (AssertionError e)
                    {
                        System.out.println(e.getMessage());
                        System.out.println("");
                        count++;
                        continue; // it should teake the user to reenter name

                    }

                }
            } else //file does not exit
            {
                try {
                    //System.out.println("");
                    String filePath = new File("").getAbsolutePath();
                    filePath.concat(" path to the property file");
                    assertThat(fileName+".txt File Does not exist In "+filePath, file.exists(), equalTo(true));
                }catch (AssertionError e)
                {
                    System.out.println(e.getMessage());
                    System.out.println("");
                    count++;
                    continue;
                }
                //System.out.println("File Does not exist: " + fileName);

                //

            }

        } while (!fileName.equalsIgnoreCase("quit"));


    }

    public static void input(Scanner sc) {
        count = 0;

        System.out.print("Enter File name or QUIT to close program: ");
        String[] a = sc.nextLine().split(" ");
 fileName = "";
        for(int i = 0; i < a.length; i++){
            fileName += a[i]+" ";
        }

        fileName = fileName.trim(); // to remove fast and last space



    }


}
